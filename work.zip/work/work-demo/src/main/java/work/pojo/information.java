package work.pojo;

import java.util.Arrays;

public class information {
    private String id;
    private String date;
    private String reason;
    private String name;
    private String gender;
    private String birthday;
    private String number;
    private String cordnumber;
    private String nation;
    private String culture;
    private String religion;
    private String marrystate;
    private String livestate;
    private String medicalpay;
    private String financial;
    private String disease_1;
    private String disease_2;
    private String disease_3;
    private String accident_1;
    private String accident_2;
    private String accident_3;
    private String accident_4;
    private String accident_5;
    private String providername;
    private String relationship;
    private String phonename;
    private String phonenumber;

    @Override
    public String toString() {
        return "information{" +
                "id='" + id + '\'' +
                ", date='" + date + '\'' +
                ", reason='" + reason + '\'' +
                ", name='" + name + '\'' +
                ", gender='" + gender + '\'' +
                ", birthday='" + birthday + '\'' +
                ", number='" + number + '\'' +
                ", cordnumber='" + cordnumber + '\'' +
                ", nation='" + nation + '\'' +
                ", culture='" + culture + '\'' +
                ", religion='" + religion + '\'' +
                ", marrystate='" + marrystate + '\'' +
                ", livestate='" + livestate + '\'' +
                ", medicalpay='" + medicalpay + '\'' +
                ", financial='" + financial + '\'' +
                ", disease_1='" + disease_1 + '\'' +
                ", disease_2='" + disease_2 + '\'' +
                ", disease_3='" + disease_3 + '\'' +
                ", accident_1='" + accident_1 + '\'' +
                ", accident_2='" + accident_2 + '\'' +
                ", accident_3='" + accident_3 + '\'' +
                ", accident_4='" + accident_4 + '\'' +
                ", accident_5='" + accident_5 + '\'' +
                ", providername='" + providername + '\'' +
                ", relationship='" + relationship + '\'' +
                ", phonename='" + phonename + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getCordnumber() {
        return cordnumber;
    }

    public void setCordnumber(String cordnumber) {
        this.cordnumber = cordnumber;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getCulture() {
        return culture;
    }

    public void setCulture(String culture) {
        this.culture = culture;
    }

    public String getMedicalpay() {
        return medicalpay;
    }

    public void setMedicalpay(String medicalpay) {
        this.medicalpay = medicalpay;
    }

    public String getMarrystate() {
        return marrystate;
    }

    public void setMarrystate(String marrystate) {
        this.marrystate = marrystate;
    }

    public String getLivestate() {
        return livestate;
    }

    public void setLivestate(String livestate) {
        this.livestate = livestate;
    }

    public String getFinancial() {
        return financial;
    }

    public void setFinancial(String financial) {
        this.financial = financial;
    }

    public String getDisease_2() {
        return disease_2;
    }

    public void setDisease_2(String disease_2) {
        this.disease_2 = disease_2;
    }

    public String getDisease_1() {
        return disease_1;
    }

    public void setDisease_1(String disease_1) {
        this.disease_1 = disease_1;
    }

    public String getDisease_3() {
        return disease_3;
    }

    public void setDisease_3(String disease_3) {
        this.disease_3 = disease_3;
    }

    public String getAccident_1() {
        return accident_1;
    }

    public void setAccident_1(String accident_1) {
        this.accident_1 = accident_1;
    }

    public String getAccident_2() {
        return accident_2;
    }

    public void setAccident_2(String accident_2) {
        this.accident_2 = accident_2;
    }

    public String getAccident_3() {
        return accident_3;
    }

    public void setAccident_3(String accident_3) {
        this.accident_3 = accident_3;
    }

    public String getAccident_4() {
        return accident_4;
    }

    public void setAccident_4(String accident_4) {
        this.accident_4 = accident_4;
    }

    public String getAccident_5() {
        return accident_5;
    }

    public void setAccident_5(String accident_5) {
        this.accident_5 = accident_5;
    }

    public String getProvidername() {
        return providername;
    }

    public void setProvidername(String providername) {
        this.providername = providername;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getPhonename() {
        return phonename;
    }

    public void setPhonename(String phonename) {
        this.phonename = phonename;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }
}
